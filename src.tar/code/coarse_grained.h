#ifndef COARSE_GRAINED_H
#define COARSE_GRAINED_H

#include <map>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <vector>

/**
 * @brief A bucket in the extendible hash table that stores key-value pairs
 */
class Bucket
{
private:
    friend class Directory; // Allows Directory to access private members

    std::map<int, std::string> elements; // Stores the key-value pairs
    int local_depth;                     // Current local depth of this bucket
    int bucket_size;                     // Maximum number of elements allowed

public:
    /**
     * @brief Constructs a new bucket
     * @param local_depth Initial local depth
     * @param bucket_size Maximum number of elements allowed
     */
    Bucket(int local_depth, int bucket_size);

    /**
     * @brief Retrieves a value by key
     * @param key Key to search for
     * @param value Pointer to store the found value
     * @return true if key exists, false otherwise
     */
    bool get(int key, std::string *value);

    /**
     * @brief Inserts a key-value pair
     * @param key Key to insert
     * @param value Value to insert
     * @return true if insertion successful, false if bucket is full
     */
    bool insert(int key, std::string value);

    /**
     * @brief Removes a key-value pair
     * @param key Key to remove
     * @return true if key was found and removed, false otherwise
     */
    bool remove(int key);

    /**
     * @brief Updates value for existing key
     * @param key Key to update
     * @param value New value
     * @throws std::invalid_argument if key doesn't exist
     */
    void update(int key, std::string value);

    /**
     * @brief Returns current number of elements
     * @return Number of elements in bucket
     */
    int size();

    /**
     * @brief Removes all elements from bucket
     */
    void clear();

    /**
     * @brief Prints the entire bucket for debugging
     */
    void print();
};

/**
 * @brief Directory managing the extendible hash table with coarse-grained
 * locking
 */
class Directory
{
private:
    mutable std::shared_mutex directory_mutex; // Lock for thread safety
    std::vector<Bucket *> buckets;             // Array of bucket pointers
    int global_depth;                          // Current global depth
    int bucket_size;                           // Maximum size of each bucket

    /**
     * @brief Computes bucket index for a key
     * @param key Key to hash
     * @return Bucket index
     */
    int hash(int key);

    /**
     * @brief Finds split image bucket index
     * @param bucket_idx Current bucket index
     * @return Index of bucket to split with
     */
    int getSplitIndex(int bucket_idx);

    /**
     * @brief Doubles directory size by increasing global depth
     */
    void increaseGlobalDepth();

    /**
     * @brief updates split idx parent pointers
     */
    void update_parent_pointers(int idx, Bucket *new_bucket, int cur_depth);

public:
    /**
     * @brief Constructs directory with initial bucket size
     * @param bucket_size Maximum elements per bucket
     */
    Directory(int bucket_size);

    /**
     * @brief Destructor - frees all buckets
     */
    ~Directory();

    /**
     * @brief Thread-safe get operation
     * @param key Key to search for
     * @param value Pointer to store found value
     * @return true if key exists, false otherwise
     */
    bool get(int key, std::string *value);

    /**
     * @brief Thread-safe insert operation
     * @param key Key to insert
     * @param value Value to insert
     */
    void insert(int key, std::string value);

    /**
     * @brief Thread-safe remove operation
     * @param key Key to remove
     * @throws std::invalid_argument if key doesn't exist
     */
    void remove(int key);

    /**
     * @brief Thread-safe update operation
     * @param key Key to update
     * @param value New value
     * @throws std::invalid_argument if key doesn't exist
     */
    void update(int key, std::string value);

    /**
     * @brief Prints the entire director for debugging
     */
    void print();
};

#endif // COARSE_GRAINED_H