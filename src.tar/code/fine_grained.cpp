#include "fine_grained.h"

#include <set>
#include <shared_mutex>

Bucket::Bucket(int local_depth, int bucket_size)
    : local_depth{local_depth}, bucket_size{bucket_size} {}

int Bucket::size() { return elements.size(); }

bool Bucket::get(int key, std::string *value) {
    auto it = elements.find(key);
    if (it == elements.end()) return false;
    *value = it->second;
    return true;
}

bool Bucket::insert(int key, std::string value) {
    if (elements.size() >= bucket_size) return false;
    elements[key] = value;
    return true;
}

bool Bucket::remove(int key) { return elements.erase(key) > 0; }

void Bucket::update(int key, std::string value) {
    if (elements.find(key) == elements.end()) {
        throw std::invalid_argument("Key not found");
    }
    elements[key] = value;
}

void Bucket::clear() { elements.clear(); }

Directory::Directory(int bucket_size)
    : global_depth{1}, bucket_size{bucket_size} {
    buckets.push_back(new Bucket(1, bucket_size));
    buckets.push_back(new Bucket(1, bucket_size));
}

Directory::~Directory() {
    std::set<Bucket *> unique_buckets;
    for (auto bucket : buckets) {
        unique_buckets.insert(bucket);
    }
    for (auto bucket : unique_buckets) {
        delete bucket;
    }
}

int Directory::hash(int key) { return key & ((1 << global_depth) - 1); }

int Directory::getSplitIndex(int bucket_idx) {
    return (bucket_idx & ((1 << (buckets[bucket_idx]->local_depth)) - 1)) ^
           (1 << (buckets[bucket_idx]->local_depth - 1));
}

void Directory::increaseGlobalDepth() {
    size_t old_size = buckets.size();
    for (size_t i = 0; i < old_size; i++) {
        buckets.push_back(buckets[i]);
    }
    global_depth++;
}

bool Directory::get(int key, std::string *value) {
    int hash_key = hash(key);

    std::shared_lock<std::shared_mutex> dir_lock(directory_mutex);
    auto bucket = buckets[hash_key];
    std::shared_lock<std::shared_mutex> lock(bucket->bucket_mutex);
    dir_lock.unlock();

    return bucket->get(key, value);
}

void Directory::insert(int key, std::string value) {
    while (true) {
        std::unique_lock<std::shared_mutex> dir_lock(directory_mutex);
        int hash_key = hash(key);
        auto bucket = buckets[hash_key];
        std::unique_lock<std::shared_mutex> bucket_lock(bucket->bucket_mutex);

        // Try simple insert first
        if (bucket->size() < bucket_size) {
            dir_lock.unlock();

            if (bucket->insert(key, value)) return;
        }

        // Need to split bucket
        if (bucket->local_depth == global_depth) {
            increaseGlobalDepth();
        }

        bucket->local_depth++;
        int split_idx = getSplitIndex(hash_key);
        auto new_bucket = new Bucket(bucket->local_depth, bucket_size);
        std::unique_lock<std::shared_mutex> new_bucket_lock(
            new_bucket->bucket_mutex);
        buckets[split_idx] = new_bucket;

        update_parent_pointers(split_idx, new_bucket, bucket->local_depth + 1);

        auto elements = bucket->elements;
        bucket->clear();

        // Redistribute elements
        for (const auto &elem : elements) {
            int new_hash = hash(elem.first);
            Bucket *target_bucket = buckets[new_hash];
            target_bucket->insert(elem.first, elem.second);
        }
        dir_lock.unlock();

        // Try to insert the new element
        hash_key = hash(key);
        bucket = buckets[hash_key];

        if (bucket->insert(key, value))
            break;
        else {
            new_bucket_lock.unlock();
            bucket_lock.unlock();
        }
    }
}

void Directory::remove(int key) {
    int hash_key = hash(key);

    // First acquire directory lock to safely access bucket
    std::unique_lock<std::shared_mutex> dir_lock(directory_mutex);
    auto bucket = buckets[hash_key];

    int split_idx = getSplitIndex(hash_key);
    auto split_bucket = buckets[split_idx];

    // Release directory lock before bucket operation
    dir_lock.unlock();

    // Lock the buckets in a consistent order to prevent deadlock
    std::unique_lock<std::shared_mutex> bucket_lock(bucket->bucket_mutex);

    // Remove the key from the bucket
    if (!bucket->remove(key)) {
        throw std::invalid_argument("Key not found");
    }

    // If bucket not empty or at minimum depth, we're done
    if (bucket->size() > 0) return;
    if (bucket->local_depth == 1) return;

    // Lock split bucket only if merge might be possible
    std::unique_lock<std::shared_mutex> split_bucket_lock(
        split_bucket->bucket_mutex);

    // Verify conditions for merge
    if (split_bucket->size() == 0 &&
        split_bucket->local_depth == bucket->local_depth) {
        Bucket *to_delete = bucket;

        // Reacquire directory lock only for the update
        std::unique_lock<std::shared_mutex> new_dir_lock(directory_mutex);

        // Update all references to point to split_bucket
        for (size_t i = 0; i < buckets.size(); i++) {
            if (buckets[i] == bucket) {
                buckets[i] = split_bucket;
            }
        }

        // Decrease depth after updating references
        split_bucket->local_depth--;

        // Release all locks before deletion
        new_dir_lock.unlock();
        split_bucket_lock.unlock();
        bucket_lock.unlock();

        delete to_delete;
    }
}

void Directory::update_parent_pointers(int idx, Bucket *new_bucket,
                                       int cur_depth) {
    if (cur_depth > global_depth) {
        return;
    }
    auto split_idx = idx | (1 << (cur_depth - 1));
    buckets[split_idx] = new_bucket;
    update_parent_pointers(idx, new_bucket, cur_depth + 1);
    update_parent_pointers(split_idx, new_bucket, cur_depth + 1);
}

void Directory::update(int key, std::string value) {
    int hash_key = hash(key);
    std::shared_lock<std::shared_mutex> dir_lock(directory_mutex);
    auto bucket = buckets[hash_key];
    std::unique_lock<std::shared_mutex> bucket_lock(bucket->bucket_mutex);
    dir_lock.unlock();

    return bucket->update(key, value);
}
