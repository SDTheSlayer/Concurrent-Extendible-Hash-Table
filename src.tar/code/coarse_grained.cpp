#include "coarse_grained.h"
#include <cassert>
#include <set>
#include <stdexcept>

Bucket::Bucket(int local_depth, int bucket_size)
    : local_depth{local_depth}, bucket_size{bucket_size} {
    elements.clear();
}

int Bucket::size() { return elements.size(); }

bool Bucket::get(int key, std::string *value) {
    auto it = elements.find(key);
    if (it == elements.end()) return false;
    *value = it->second;
    return true;
}

bool Bucket::insert(int key, std::string value) {
    if (elements.size() >= bucket_size) return false;
    elements[key] = value;
    return true;
}

bool Bucket::remove(int key) { return elements.erase(key) > 0; }


void Bucket::update(int key, std::string value) {
    if (elements.find(key) == elements.end()) {
        throw std::invalid_argument("Key not found");
    }
    elements[key] = value;
}

void Bucket::print() {
    printf("Bucket local depth %d, bucket size %d\n", local_depth, bucket_size);
    for (auto &ele : elements) {
        printf("%d -> %s, ", ele.first, ele.second.c_str());
    }
    printf("\n");
}

void Bucket::clear() { elements.clear(); }

Directory::Directory(int bucket_size)
    : global_depth{1}, bucket_size{bucket_size} {
    // Initialize with two buckets for depth 1
    buckets.push_back(new Bucket(1, bucket_size));
    buckets.push_back(new Bucket(1, bucket_size));
}

Directory::~Directory() {
    std::set<Bucket *> unique_buckets(buckets.begin(), buckets.end());
    for (auto bucket : unique_buckets) {
        delete bucket;
    }
}

int Directory::hash(int key) { 
    return key & ((1 << global_depth) - 1); 
}


int Directory::getSplitIndex(int bucket_idx) {
    return (bucket_idx & ((1 << (buckets[bucket_idx]->local_depth)) - 1)) ^
           (1 << (buckets[bucket_idx]->local_depth - 1));
}


void Directory::increaseGlobalDepth() {
    size_t old_size = buckets.size();
    buckets.resize(old_size * 2);
    for (size_t i = 0; i < old_size; i++) {
        buckets[i + old_size] = buckets[i];
    }
    global_depth++;
}

bool Directory::get(int key, std::string *value) {
    std::shared_lock<std::shared_mutex> lock(directory_mutex);
    return buckets[hash(key)]->get(key, value);
}

void Directory::insert(int key, std::string value) {
    std::unique_lock<std::shared_mutex> lock(directory_mutex);
    int hash_key = hash(key);
    Bucket *bucket = buckets[hash_key];

    // Try simple insert first
    if (bucket->size() < bucket_size) {
        bucket->insert(key, value);
        return;
    }

    // Handle bucket overflow with splitting
    while (true) {
        if (bucket->local_depth == global_depth) {
            increaseGlobalDepth();
        }
        
        // Create new bucket and redistribute elements
        bucket->local_depth++;
        int split_idx = getSplitIndex(hash_key);
        buckets[split_idx] = new Bucket(bucket->local_depth, bucket_size);
        
        // Update directory pointers for new bucket
        update_parent_pointers(split_idx, buckets[split_idx],
                             bucket->local_depth + 1);
                             
        // Redistribute existing elements
        auto elements = bucket->elements;
        bucket->clear();
        for (const auto &elem : elements) {
            int new_hash = hash(elem.first);
            buckets[new_hash]->insert(elem.first, elem.second);
        }

        // Try inserting new element
        hash_key = hash(key);
        bucket = buckets[hash_key];
        if (bucket->insert(key, value)) break;
    }
}


void Directory::remove(int key) {
    std::unique_lock<std::shared_mutex> dir_lock(directory_mutex);
    int hash_key = hash(key);
    Bucket *bucket = buckets[hash_key];

    if (!bucket->remove(key)) {
        throw std::invalid_argument("Key not found");
    }

    // Check if bucket merging is possible
    if (bucket->size() > 0 || bucket->local_depth == 1) return;

    int split_idx = getSplitIndex(hash_key);
    Bucket *split_bucket = buckets[split_idx];

    // Merge buckets if possible
    if (split_bucket->size() == 0 &&
        split_bucket->local_depth == bucket->local_depth) {
        Bucket *to_delete = bucket;
        
        // Update directory pointers
        for (auto &b : buckets) {
            if (b == bucket) b = split_bucket;
        }
        
        split_bucket->local_depth--;
        delete to_delete;
    }
}


void Directory::update(int key, std::string value) {
    std::unique_lock<std::shared_mutex> lock(directory_mutex);
    buckets[hash(key)]->update(key, value);
}

void Directory::update_parent_pointers(int idx, Bucket *new_bucket,
                                       int cur_depth) {
    if (cur_depth > global_depth) {
        return;
    }
    auto split_idx = idx | (1 << (cur_depth - 1));
    buckets[split_idx] = new_bucket;
    buckets[idx] = new_bucket;
    update_parent_pointers(idx, new_bucket, cur_depth + 1);
    update_parent_pointers(split_idx, new_bucket, cur_depth + 1);
}

void Directory::print() {
    return;
    printf("Dir global depth %d, bucket size %d\n", global_depth, bucket_size);
    for (int i = 0; i < buckets.size(); i++) {
        printf("Bucket idx %d  ", i);
        buckets[i]->print();
    }
    printf("\n");
}