#ifndef CONCURRENT_ORDERED_COLLECTION_H
#define CONCURRENT_ORDERED_COLLECTION_H

#include <atomic>
#include <cstdio>
#include <vector>
#include <string>

// Lock-free implementation of a sorted linked list that supports concurrent operations
class LockFreeSortedList {
public:
    // Node structure representing each element in the list
    struct Node {
        unsigned int key;              // Unique identifier for the node
        std::string value;            // Data stored in the node
        std::atomic<Node*> successor;  // Atomic pointer to next node for thread safety
        
        Node(unsigned int id, std::string content)
            : key(id), value(content), successor(nullptr) {}
    };

    // Atomic pointers and counters for thread-safe operations
    std::atomic<Node*> root;                    // Head of the list
    std::atomic<unsigned int> element_count;     // Number of elements in the list
    std::atomic<unsigned long> operation_count;  // Total number of operations performed

    // Initialize empty list
    LockFreeSortedList() : root(nullptr), element_count(0), operation_count(0) {}
    ~LockFreeSortedList() { removeAll(); }

    // Returns current number of elements in the list
    unsigned int count() const { 
        return element_count.load(); 
    }

    // Returns total number of operations performed on the list
    unsigned long operationTotal() const { 
        return operation_count.load(); 
    }

    // Removes all elements from the list
    void removeAll() {
        Node* current = root.load();
        Node* temp = nullptr;
        root = nullptr;

        // Iterate through list and delete nodes
        while (current) {
            temp = current->successor;
            current->successor = nullptr;
            delete current;
            current = temp;

            // Check for any new nodes added during cleanup
            if (!current) {
                current = root.load();
                root = nullptr;
            }
        }
        element_count.store(0);
        operation_count.store(0);
    }

    // Searches for a node with given id starting from startNode
    bool locate(unsigned int id, Node* startNode, std::string* result, bool* requiresScan = nullptr) {
        operation_count.fetch_add(1);
        Node* current = startNode;

        // Traverse until we find the node or confirm it doesn't exist
        while (current) {
            if (current->key > id) return false;
            if (current->key == id) {
                *result = std::string(current->value);
                return true;
            }
            current = current->successor;
        }
        return false;
    }

    // Adds a new node to the list in sorted order
    bool add(unsigned int id, std::string content) {
        operation_count.fetch_add(1);
        Node* current = root.load();
        bool completed = false;

        // Handle empty list case
        if (!current) {
            root.store(new Node(id, content));
            element_count.fetch_add(1);
            return true;
        }

        // Handle new head node case
        if (current->key > id) {
            Node* newNode = new Node(id, content);
            newNode->successor = current;
            if (!root.compare_exchange_strong(current, newNode)) {
                delete newNode;
                return add(id, content);  // Retry if CAS fails
            }
            element_count.fetch_add(1);
            return true;
        }

        // Handle general insertion case
        while (!completed) {
            Node* next = nullptr;
            // Find insertion point
            while (current) {
                if (current->key == id && current->value == content) 
                    return false;  // Duplicate found
                next = current->successor;
                if (!next || next->key > id) break;
                current = next;
            }

            // Attempt to insert new node
            Node* newNode = new Node(id, content);
            newNode->successor.store(next);

            if (!current->successor.compare_exchange_strong(next, newNode)) {
                delete newNode;
                current = root.load();  // Retry from start if CAS fails
            } else {
                completed = true;
                element_count.fetch_add(1);
            }
        }
        return completed;
    }

    // Removes a node with the given id from the list
    bool erase(unsigned int id, Node* startHint = nullptr) {
        operation_count.fetch_add(1);
        Node* current = root.load();
        Node* next = nullptr;
        bool removed = false;

        // Handle head node removal
        if (!removed && current && current->key == id) {
            next = current->successor;
            if (root.compare_exchange_strong(current, next)) {
                next = current;
                removed = true;
                element_count.fetch_sub(1);
            }
        }

        // Handle general case removal
        while (current && !removed) {
            next = current->successor;
            if (!next || next->key > id) return false;

            if (next->key == id) {
                // Attempt to remove node atomically
                if (!current->successor.compare_exchange_strong(next, next->successor)) {
                    current = root.load();  // Retry from start if CAS fails
                    continue;
                }
                removed = true;
                element_count.fetch_sub(1);
                break;
            }
            current = next;
        }

        if (removed) {
            delete next;
            return true;
        }
        return false;
    }

    // Finds and returns pointer to node with given id
    Node* findNode(unsigned int id) {
        operation_count.fetch_add(1);
        Node* current = root;

        while (current) {
            if (current->key > id) return nullptr;
            if (current->key == id) return current;
            current = current->successor;
        }
        return nullptr;
    }

    // Returns pointer to the root node
    Node* getRoot() const { return root; }
};

#endif
