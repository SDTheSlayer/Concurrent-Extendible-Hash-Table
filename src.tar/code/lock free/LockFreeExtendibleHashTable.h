#ifndef LOCK_FREE_EXTENDIBLE_HASH_TABLE_H
#define LOCK_FREE_EXTENDIBLE_HASH_TABLE_H

#include <atomic>
#include <string>

#include "LockFreeSortedList.h"

/**
 * @brief A lock-free extendible hash table implementation using recursive split
 * ordering
 *
 * This implementation uses a single lock-free sorted list to store all
 * elements, with bucket pointers referencing nodes within this list. The table
 * automatically resizes when the load factor exceeds 2.
 */
class LockFreeExtendibleHashTable {
   public:
    LockFreeExtendibleHashTable();

    /**
     * @brief Retrieves the value associated with a key
     * @param key The key to look up
     * @param value Pointer to store the retrieved value
     * @return true if key exists, false otherwise
     */
    bool get(unsigned int key, std::string* value);

    /**
     * @brief Inserts a key-value pair into the hash table
     * @param key The key to insert
     * @param value The value to associate with the key
     */
    void insert(unsigned int key, std::string value);

    /**
     * @brief Removes a key-value pair from the hash table
     * @param key The key to remove
     */
    void remove(unsigned int key);

    /**
     * @brief Updates the value associated with a key
     * @param key The key to update
     * @param value The new value to associate with the key
     */
    void update(unsigned int key, std::string value);

   private:
    using ListItem =
        LockFreeSortedList::Node;

    // Core data structures
    LockFreeSortedList T;  // Main storage list
    std::atomic<ListItem**> buckets;                  // Bucket array
    std::atomic<unsigned int> count;                  // Number of elements
    std::atomic<unsigned int> size;                   // Number of buckets

    /**
     * @brief Initializes a bucket using recursive split ordering
     * @param bucket The bucket number to initialize
     */
    void initBucket(unsigned int bucket);

    /**
     * @brief Transforms a key for the split-ordered list
     * @param key The original key
     * @param isDummy Whether this is a dummy key for bucket management
     * @return The transformed key maintaining split-ordering
     */
    unsigned int createKey(unsigned int key, bool isDummy = false);

    /**
     * @brief Reverses the bits of a 32-bit unsigned integer
     *
     * This function reverses all bits in the input number using a series of bit
     * manipulations:
     * 1. Swaps all pairs of 16 bits
     * 2. Swaps all pairs of 8 bits
     * 3. Swaps all pairs of 4 bits
     * 4. Swaps all pairs of 2 bits
     * 5. Swaps all pairs of 1 bit
     *
     * @param n The 32-bit unsigned integer to reverse
     * @return unsigned int The bit-reversed version of the input
     */
    unsigned int getBitReversedInt(unsigned int n);

    /**
     * @brief Finds the parent bucket in the recursive split ordering
     *
     * This function implements the recursive split ordering by:
     * 1. Finding the most significant set bit in the key
     * 2. Clearing that bit to get the parent bucket
     *
     * For example:
     * - getParent(6) = 4  // 110 -> 100
     * - getParent(5) = 4  // 101 -> 100
     * - getParent(4) = 0  // 100 -> 000
     *
     * @param key The bucket number to find the parent of
     * @return unsigned int The parent bucket number, or 0 if key is 0
     */
    unsigned int getSplitOrderParent(unsigned int key);
};

#endif  // LOCK_FREE_EXTENDIBLE_HASH_TABLE_H