#include <bits/stdc++.h>
#include <sys/resource.h>

#include <cassert>
#include <iostream>
#include <random>
#include <string>
#include <thread>

#include "LockFreeExtendibleHashTable.h"

using namespace std;

struct TestResults {
    double duration_millis;
    double peak_memory_kb;
};

// Pure reader and writer thread functions
void pure_reader_thread(LockFreeExtendibleHashTable* table, int start,
                        int num) {
    std::string value;
    for (int i = start; i < num + start; ++i) {
        try {
            table->get(i, &value);
        } catch (const std::exception& e) {
            // Handle exception
        }
    }
}

void pure_writer_thread(LockFreeExtendibleHashTable* table, int start,
                        int num) {
    for (int i = start; i < num + start; ++i) {
        try {
            table->insert(i, "value" + std::to_string(i));
        } catch (const std::exception& e) {
            std::cerr << "Exception during insert 1: " << i << e.what()
                      << std::endl;
        }
    }
}

void pure_deletion_thread(LockFreeExtendibleHashTable* table, int start,
                          int num) {
    for (int i = start; i < num + start; ++i) {
        try {
            table->remove(i);
        } catch (const std::exception& e) {
            std::cerr << "Exception during delete 1: " << i << e.what()
                      << std::endl;
        }
    }
}

void test_crud_generic(LockFreeExtendibleHashTable* directory, int start,
                       int num) {
    pure_writer_thread(directory, start, num);
    pure_reader_thread(directory, start, num);
    pure_deletion_thread(directory, start, num);
}

void run_mixed_test(int num_readers, int num_writers, int ops_per_thread,
                    int bucket_size) {
    auto directory = std::make_unique<LockFreeExtendibleHashTable>();
    vector<thread> threads;

    // Launch pure writer threads
    for (int i = 0; i < num_writers; i++) {
        threads.push_back(thread(pure_writer_thread, directory.get(),
                                 i * ops_per_thread, ops_per_thread));
    }

    // Launch pure reader threads
    for (int i = 0; i < num_readers; i++) {
        threads.push_back(thread(pure_reader_thread, directory.get(),
                                 i * ops_per_thread, ops_per_thread));
    }

    for (auto& t : threads) {
        t.join();
    }
}

void run_crud_test(int num_threads, int ops_per_thread, int bucket_size) {
    auto directory = std::make_unique<LockFreeExtendibleHashTable>();
    vector<thread> threads;

    for (int i = 0; i < num_threads; i++) {
        threads.push_back(thread(test_crud_generic, directory.get(),
                                 i * ops_per_thread, ops_per_thread));
    }

    for (auto& t : threads) {
        t.join();
    }
}

class BenchmarkRunner {
   private:
    double getCurrentMemoryUsage() {
        struct rusage usage;
        getrusage(RUSAGE_SELF, &usage);
        return usage.ru_maxrss;
    }

    TestResults runMixedTest(int num_readers, int num_writers,
                             int ops_per_thread, int bucket_size) {
        TestResults results;
        double initial_memory = getCurrentMemoryUsage();
        double peak_memory = initial_memory;
        bool test_running = true;

        thread memory_monitor([&]() {
            while (test_running) {
                double current_memory = getCurrentMemoryUsage();
                peak_memory = max(peak_memory, current_memory);
                this_thread::sleep_for(chrono::milliseconds(1));
            }
        });

        auto start = chrono::high_resolution_clock::now();
        run_mixed_test(num_readers, num_writers, ops_per_thread, bucket_size);
        auto stop = chrono::high_resolution_clock::now();

        test_running = false;
        memory_monitor.join();

        results.duration_millis =
            chrono::duration_cast<chrono::milliseconds>(stop - start).count();
        results.peak_memory_kb = peak_memory - initial_memory;
        return results;
    }

    TestResults runCrudTest(int num_readers, int num_writers,
                            int ops_per_thread, int bucket_size) {
        TestResults results;
        double initial_memory = getCurrentMemoryUsage();
        double peak_memory = initial_memory;
        bool test_running = true;

        thread memory_monitor([&]() {
            while (test_running) {
                double current_memory = getCurrentMemoryUsage();
                peak_memory = max(peak_memory, current_memory);
                this_thread::sleep_for(chrono::milliseconds(1));
            }
        });

        auto start = chrono::high_resolution_clock::now();
        run_crud_test(num_readers + num_writers, ops_per_thread, bucket_size);
        auto stop = chrono::high_resolution_clock::now();

        test_running = false;
        memory_monitor.join();

        results.duration_millis =
            chrono::duration_cast<chrono::milliseconds>(stop - start).count();
        results.peak_memory_kb = peak_memory - initial_memory;
        return results;
    }

   public:
    void runBenchmark(int num_readers, int num_writers, int ops_per_thread,
                      int bucket_size, int num_iterations) {
        vector<TestResults> mixed_results;
        vector<TestResults> crud_results;

        cout << "\nRunning benchmarks with:" << endl
             << "Readers: " << num_readers << ", Writers: " << num_writers
             << endl
             << "Operations per thread: " << ops_per_thread << endl
             << "Iterations: " << num_iterations << endl;

        for (int i = 0; i < num_iterations; i++) {
            cout << "\nIteration " << (i + 1) << ":" << endl;

            auto mixed_result = runMixedTest(num_readers, num_writers,
                                             ops_per_thread, bucket_size);
            mixed_results.push_back(mixed_result);

            auto crud_result = runCrudTest(num_readers, num_writers,
                                           ops_per_thread, bucket_size);
            crud_results.push_back(crud_result);

            printIterationResults("Mixed Test", mixed_result);
            printIterationResults("CRUD Test", crud_result);
        }

        printAverageResults("Mixed Test", mixed_results);
        printAverageResults("CRUD Test", crud_results);
    }

   private:
    void printIterationResults(const string& test_name,
                               const TestResults& results) {
        cout << test_name << " Results:" << endl
             << "Duration: " << results.duration_millis << " milliseconds"
             << endl
             << "Peak Memory: " << results.peak_memory_kb << " KB" << endl;
    }

    void printAverageResults(const string& test_name,
                             const vector<TestResults>& all_results) {
        TestResults avg{0, 0};
        for (const auto& result : all_results) {
            avg.duration_millis += result.duration_millis;
            avg.peak_memory_kb += result.peak_memory_kb;
        }

        int n = all_results.size();
        avg.duration_millis /= n;
        avg.peak_memory_kb /= n;

        cout << "\nAverage " << test_name << " Results:" << endl
             << "Duration: " << avg.duration_millis << " milliseconds" << endl
             << "Memory Usage: " << avg.peak_memory_kb << " KB" << endl;
    }
};

int main(int argc, char* argv[]) {
    int num_readers = 1;
    int num_writers = 1;
    int ops_per_thread = 10;
    int bucket_size = 20;
    int num_iterations = 1;

    for (int i = 1; i < argc; i++) {
        string arg = argv[i];
        if (arg == "-r" && i + 1 < argc) {
            num_readers = atoi(argv[++i]);
        } else if (arg == "-w" && i + 1 < argc) {
            num_writers = atoi(argv[++i]);
        } else if (arg == "-n" && i + 1 < argc) {
            ops_per_thread = atoi(argv[++i]);
        } else if (arg == "-b" && i + 1 < argc) {
            bucket_size = atoi(argv[++i]);
        } else if (arg == "-i" && i + 1 < argc) {
            num_iterations = atoi(argv[++i]);
        }
    }

    BenchmarkRunner runner;
    runner.runBenchmark(num_readers, num_writers, ops_per_thread, bucket_size,
                        num_iterations);
    return 0;
}
