#include "LockFreeExtendibleHashTable.h"

#include <atomic>
#include <cassert>

#include "LockFreeSortedList.h"

using ListItem = LockFreeSortedList::Node;

unsigned int LockFreeExtendibleHashTable::getBitReversedInt(unsigned int n) {
    n = ((n & 0xffff0000) >> 16) | ((n & 0x0000ffff) << 16);
    n = ((n & 0xff00ff00) >> 8) | ((n & 0x00ff00ff) << 8);
    n = ((n & 0xf0f0f0f0) >> 4) | ((n & 0x0f0f0f0f) << 4);
    n = ((n & 0xcccccccc) >> 2) | ((n & 0x33333333) << 2);
    n = ((n & 0xaaaaaaaa) >> 1) | ((n & 0x55555555) << 1);
    return n;
}

// Finds and clears the most significant set bit
// Used for maintaining the recursive split ordering
unsigned int LockFreeExtendibleHashTable::getSplitOrderParent(
    unsigned int key) {
    if (key == 0) return 0;
    unsigned int mask = 1u << 31;
    while ((key & mask) == 0) mask >>= 1;
    return key & ~mask;
}

// Initialize hash table with size 2 and a dummy head node
LockFreeExtendibleHashTable::LockFreeExtendibleHashTable() {
    count.store(0);
    size.store(2);

    auto initial_buckets = new ListItem*[2]();
    buckets.store(initial_buckets);

    // Initialize with bucket 0
    T.add(createKey(0, true), "dummy");
    initial_buckets[0] = T.root;
}

// Creates a key by optionally setting LSB and reversing bits
// Regular keys have their LSB set to distinguish from dummy keys
// OPTIMIZATION: set MSB instead of LSB and this causes speeds up
unsigned int LockFreeExtendibleHashTable::createKey(unsigned int key,
                                                    bool isDummy) {
    if (isDummy) return getBitReversedInt(key);
    return getBitReversedInt(key | (1 << 31));
}

// Initializes a bucket in a thread-safe way using recursive split ordering
void LockFreeExtendibleHashTable::initBucket(unsigned int bucket) {
    auto curr_buckets = buckets.load();
    if (curr_buckets[bucket]) return;

    // Ensure parent bucket is initialized first (recursive split ordering)
    auto parent = getSplitOrderParent(bucket);
    if (!curr_buckets[parent]) {
        initBucket(parent);
        curr_buckets = buckets.load();
    }

    // Create and add dummy node for the bucket
    auto dummyKey = createKey(bucket, true);
    T.add(dummyKey, "dummy");
    auto dummyBucket = T.findNode(dummyKey);

    // Atomically set the bucket pointer using compare-and-swap
    ListItem* expected = nullptr;
    if (std::atomic_compare_exchange_strong(
            reinterpret_cast<std::atomic<ListItem*>*>(&curr_buckets[bucket]),
            &expected, dummyBucket)) {
        assert(dummyBucket->key == dummyKey);
    }
}

// Retrieves a value from the hash table
bool LockFreeExtendibleHashTable::get(unsigned int key, std::string* value) {
    auto curr_size = size.load(std::memory_order_acquire);
    auto bucket = key % curr_size;
    auto curr_buckets = buckets.load(std::memory_order_acquire);

    if (!curr_buckets[bucket]) {
        initBucket(bucket);
        curr_buckets = buckets.load(std::memory_order_acquire);
    }

    return T.locate(createKey(key), curr_buckets[bucket], value);
}

// Inserts a key-value pair with automatic resizing
void LockFreeExtendibleHashTable::insert(unsigned int key, std::string value) {
    while (true) {
        auto curr_size = size.load();
        auto bucket = key % curr_size;
        auto curr_buckets = buckets.load();

        if (!curr_buckets[bucket]) {
            initBucket(bucket);
            curr_buckets = buckets.load();
        }

        // Try to add the key-value pair
        if (T.add(createKey(key), value)) {
            auto old_count = count.fetch_add(1);

            // Resize if load factor exceeds 2
            if ((old_count + 1) / curr_size >= 2) {
                auto old_buckets = curr_buckets;
                auto new_buckets = new ListItem*[2 * curr_size]();
                std::copy(old_buckets, old_buckets + curr_size, new_buckets);

                if (size.compare_exchange_strong(curr_size, 2 * curr_size)) {
                    buckets.store(new_buckets);
                    delete[] old_buckets;
                } else {
                    delete[] new_buckets;  // Another thread won the race
                }
            }
            return;
        }
    }
}

// Removes a key-value pair from the hash table
void LockFreeExtendibleHashTable::remove(unsigned int key) {
    auto curr_size = size.load();
    auto bucket = key % curr_size;
    auto curr_buckets = buckets.load();

    if (!curr_buckets[bucket]) {
        initBucket(bucket);
    }

    if (T.erase(createKey(key))) {
        count.fetch_sub(1);
    }
}

// Updates a key's value by removing and reinserting
void LockFreeExtendibleHashTable::update(unsigned int key, std::string value) {
    remove(key);
    insert(key, value);
}
