# Parallel-Extendible-Hash-Table

### How to run:

```
cd code
make test_coarse_grained
./test_coarse_grained

cd code
make test_fine_grained
./test_fine_grained

cd code/lock\ free
make test_lock_free
./test_lock_free
```

### Cleanup
```
make clean
```
